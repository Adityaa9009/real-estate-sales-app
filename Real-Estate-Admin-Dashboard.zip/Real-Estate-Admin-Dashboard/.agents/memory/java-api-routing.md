---
name: Java API routing
description: The admin app uses the existing managed /api service to expose the Java SQLite backend.
---

The Java backend is started by the existing API artifact workflow, because the shared proxy routes `/api` requests to that service before the root web artifact. The React/Vite app remains a separate web artifact and consumes the Java routes through generated hooks.

**Why:** Path-based routing gives the `/api` service precedence over the root web service, so starting Java only inside the frontend workflow would make browser requests hit the starter API instead.

**How to apply:** Keep the API workflow pointed at the Java Maven entry point and keep the frontend API base path at `/api`; restart both managed workflows after backend or frontend changes.

Customer timestamps are server-owned: the customer create/update payload intentionally excludes `updatedAt`, and Java derives it before writing SQLite.

**Why:** Requiring a database timestamp from the client caused Add Customer inserts to fail with a NOT NULL constraint even though all visible form fields were filled.

**How to apply:** When adding or editing customer records, validate user-entered fields but always derive `updated_at` in the Java handler.