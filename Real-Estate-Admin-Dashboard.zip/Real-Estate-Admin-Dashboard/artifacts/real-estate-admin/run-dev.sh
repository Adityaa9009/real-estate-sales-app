#!/usr/bin/env bash
set -euo pipefail

pnpm exec vite --config vite.config.ts --host 0.0.0.0