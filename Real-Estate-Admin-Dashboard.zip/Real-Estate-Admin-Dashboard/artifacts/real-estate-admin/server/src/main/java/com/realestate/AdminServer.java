package com.realestate;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Executors;

public final class AdminServer {
  private static final Gson GSON = new Gson();
  private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("MMM d, yyyy · h:mm a");
  private static final DateTimeFormatter DISPLAY_DATE = DateTimeFormatter.ofPattern("MMM d, yyyy");
  private static final String DB_PATH = "server/data/real_estate.db";
  private final Connection connection;

  private AdminServer() throws Exception {
    Files.createDirectories(Path.of("server/data"));
    Class.forName("org.sqlite.JDBC");
    connection = DriverManager.getConnection("jdbc:sqlite:" + DB_PATH);
    connection.setAutoCommit(true);
    initialize();
  }

  public static void main(String[] args) throws Exception {
    String configuredPort = System.getenv().getOrDefault("PORT", System.getenv().getOrDefault("JAVA_API_PORT", "5050"));
    int port = Integer.parseInt(configuredPort);
    AdminServer app = new AdminServer();
    HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", port), 0);
    server.createContext("/", app::handle);
    server.setExecutor(Executors.newFixedThreadPool(8));
    server.start();
    System.out.println("Java admin API listening on " + port);
  }

  private void initialize() throws SQLException {
    try (Statement statement = connection.createStatement()) {
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
            email TEXT NOT NULL, phone TEXT NOT NULL, position TEXT NOT NULL, status TEXT NOT NULL, joined_date TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
            phone TEXT NOT NULL, email TEXT NOT NULL, address TEXT NOT NULL, property TEXT NOT NULL,
            status TEXT NOT NULL, updated_at TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS assignments (
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, employee_id INTEGER NOT NULL,
            position TEXT NOT NULL, assigned_date TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS visits (
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, employee_name TEXT NOT NULL,
            scheduled_at TEXT NOT NULL, status TEXT NOT NULL, completed_at TEXT, selfie TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS recordings (
            id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT NOT NULL, employee_name TEXT NOT NULL,
            recorded_at TEXT NOT NULL, duration TEXT NOT NULL, status TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, message TEXT NOT NULL,
            published INTEGER NOT NULL, date TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT, employee_name TEXT NOT NULL, login_time TEXT NOT NULL,
            logout_time TEXT NOT NULL, activity TEXT NOT NULL, date TEXT NOT NULL
          )""");
      statement.executeUpdate("""
          CREATE TABLE IF NOT EXISTS profile (
            id INTEGER PRIMARY KEY CHECK (id = 1), name TEXT NOT NULL, email TEXT NOT NULL,
            phone TEXT NOT NULL, picture TEXT NOT NULL
          )""");
    }
    seed();
  }

  private void seed() throws SQLException {
    if (count("employees") == 0) {
      String[][] rows = {
          {"EMP-1001", "Arjun Mehta", "arjun@horizonhomes.co", "+91 98765 12410", "Inside Sales Employee"},
          {"EMP-1002", "Diya Shah", "diya@horizonhomes.co", "+91 98765 12411", "Inside Sales Employee"},
          {"EMP-1003", "Kabir Rao", "kabir@horizonhomes.co", "+91 98765 12412", "Outside Sales Employee"},
          {"EMP-1004", "Meera Iyer", "meera@horizonhomes.co", "+91 98765 12413", "Outside Sales Employee"},
          {"EMP-1005", "Rohan Kapoor", "rohan@horizonhomes.co", "+91 98765 12414", "Executive"},
          {"EMP-1006", "Ishita Nair", "ishita@horizonhomes.co", "+91 98765 12415", "Inside Sales Employee"},
          {"EMP-1007", "Aarav Singh", "aarav@horizonhomes.co", "+91 98765 12416", "Outside Sales Employee"},
          {"EMP-1008", "Nisha Menon", "nisha@horizonhomes.co", "+91 98765 12417", "Executive"}
      };
      try (PreparedStatement ps = connection.prepareStatement(
          "INSERT INTO employees(employee_id,name,email,phone,position,status,joined_date) VALUES(?,?,?,?,?,'Active',?)")) {
        for (String[] row : rows) {
          for (int i = 0; i < row.length; i++) ps.setString(i + 1, row[i]);
          ps.setString(6, "2025-" + String.format("%02d", 1 + (Integer.parseInt(row[0].substring(4)) % 8)) + "-12");
          ps.executeUpdate();
        }
      }
    }
    if (count("customers") == 0) {
      String[][] rows = {
          {"CUS-2401", "Ananya Desai", "9876502401", "ananya.d@gmail.com", "Whitefield, Bengaluru", "The Grove Residences", "Interested"},
          {"CUS-2402", "Vikram Malhotra", "9876502402", "vikram.m@gmail.com", "Indiranagar, Bengaluru", "Skyline One", "Visit Scheduled"},
          {"CUS-2403", "Priya Krishnan", "9876502403", "priya.k@gmail.com", "Koramangala, Bengaluru", "The Grove Residences", "Contacted"},
          {"CUS-2404", "Siddharth Jain", "9876502404", "sid.jain@gmail.com", "HSR Layout, Bengaluru", "Lakeview Terraces", "New"},
          {"CUS-2405", "Neha Bhat", "9876502405", "neha.bhat@gmail.com", "JP Nagar, Bengaluru", "Palm Court", "Not Interested"},
          {"CUS-2406", "Rahul Verma", "9876502406", "rahul.v@gmail.com", "Yelahanka, Bengaluru", "Northstar Villas", "Assigned"},
          {"CUS-2407", "Aditi Rao", "9876502407", "aditi.rao@gmail.com", "Hebbal, Bengaluru", "Lakeview Terraces", "Interested"},
          {"CUS-2408", "Manish Gupta", "9876502408", "manish.g@gmail.com", "Marathahalli, Bengaluru", "Skyline One", "Contacted"},
          {"CUS-2409", "Tanya Joseph", "9876502409", "tanya.j@gmail.com", "Sarjapur, Bengaluru", "The Grove Residences", "New"},
          {"CUS-2410", "Karan Sethi", "9876502410", "karan.sethi@gmail.com", "Bellandur, Bengaluru", "Palm Court", "Visit Completed"},
          {"CUS-2411", "Pooja Nair", "9876502411", "pooja.nair@gmail.com", "BTM Layout, Bengaluru", "Northstar Villas", "Assigned"},
          {"CUS-2412", "Dev Anand", "9876502412", "dev.anand@gmail.com", "Richmond Town, Bengaluru", "Skyline One", "Interested"},
          {"CUS-2413", "Sana Sheikh", "9876502413", "sana.s@gmail.com", "Jayanagar, Bengaluru", "Lakeview Terraces", "Not Interested"},
          {"CUS-2414", "Aditya Kulkarni", "9876502414", "aditya.k@gmail.com", "Basavanagudi, Bengaluru", "Palm Court", "New"},
          {"CUS-2415", "Lavanya Reddy", "9876502415", "lavanya.r@gmail.com", "Electronic City, Bengaluru", "Northstar Villas", "Visit Scheduled"}
      };
      try (PreparedStatement ps = connection.prepareStatement(
          "INSERT INTO customers(customer_id,name,phone,email,address,property,status,updated_at) VALUES(?,?,?,?,?,?,?,?)")) {
        for (String[] row : rows) {
          for (int i = 0; i < row.length; i++) ps.setString(i + 1, row[i]);
          ps.setString(8, "Sep 05, 2026 · 09:20 AM");
          ps.executeUpdate();
        }
      }
    }
    seedSimple("visits", "INSERT INTO visits(customer_name,employee_name,scheduled_at,status,completed_at,selfie) VALUES(?,?,?,?,?,?)",
        new String[][]{{"Vikram Malhotra", "Kabir Rao", "Sep 05, 2026 · 11:30 AM", "Scheduled", null, "VM"},
            {"Karan Sethi", "Meera Iyer", "Sep 04, 2026 · 03:00 PM", "Completed", "Sep 04, 2026 · 04:15 PM", "KS"},
            {"Lavanya Reddy", "Aarav Singh", "Sep 06, 2026 · 10:00 AM", "Scheduled", null, "LR"}});
    seedSimple("recordings", "INSERT INTO recordings(customer_name,employee_name,recorded_at,duration,status) VALUES(?,?,?,?,?)",
        new String[][]{{"Ananya Desai", "Arjun Mehta", "Sep 05, 2026 · 09:12 AM", "04:26", "Ready"},
            {"Aditi Rao", "Diya Shah", "Sep 04, 2026 · 05:48 PM", "02:18", "Ready"},
            {"Dev Anand", "Ishita Nair", "Sep 03, 2026 · 11:05 AM", "06:42", "Ready"}});
    seedSimple("announcements", "INSERT INTO announcements(title,message,published,date) VALUES(?,?,?,?)",
        new String[][]{{"Independence Day office hours", "The office will operate with a reduced team on August 15. Please plan customer visits accordingly.", "1", "Aug 12, 2026"},
            {"September pipeline focus", "Prioritise follow-ups for interested customers and confirm all scheduled visits by Friday.", "1", "Sep 01, 2026"}});
    seedSimple("activities", "INSERT INTO activities(employee_name,login_time,logout_time,activity,date) VALUES(?,?,?,?,?)",
        new String[][]{{"Arjun Mehta", "09:02 AM", "06:14 PM", "Updated 12 customer records", "Sep 05, 2026"},
            {"Kabir Rao", "08:48 AM", "05:52 PM", "Completed a property visit", "Sep 04, 2026"},
            {"Diya Shah", "09:15 AM", "06:02 PM", "Added 4 follow-up notes", "Sep 04, 2026"},
            {"Meera Iyer", "08:56 AM", "06:20 PM", "Uploaded 2 visit selfies", "Sep 03, 2026"}});
    if (count("profile") == 0) {
      try (PreparedStatement ps = connection.prepareStatement("INSERT INTO profile(id,name,email,phone,picture) VALUES(1,?,?,?,?)")) {
        ps.setString(1, "Aarav Sharma"); ps.setString(2, "admin@horizonhomes.co"); ps.setString(3, "+91 98765 10000"); ps.setString(4, "AS"); ps.executeUpdate();
      }
    }
    if (count("assignments") == 0) {
      try (PreparedStatement ps = connection.prepareStatement("INSERT INTO assignments(customer_id,employee_id,position,assigned_date) VALUES(?,?,?,?)")) {
        int[][] pairs = {{1,1},{2,3},{6,2},{7,4},{10,3},{11,6},{12,2},{15,7}};
        for (int[] pair : pairs) { ps.setInt(1,pair[0]); ps.setInt(2,pair[1]); ps.setString(3, pair[1] == 3 || pair[1] == 4 || pair[1] == 7 ? "Outside Sales Employee" : "Inside Sales Employee"); ps.setString(4, "Sep 05, 2026"); ps.executeUpdate(); }
      }
    }
  }

  private void seedSimple(String table, String sql, String[][] rows) throws SQLException {
    if (count(table) > 0) return;
    try (PreparedStatement ps = connection.prepareStatement(sql)) {
      for (String[] row : rows) {
        for (int i = 0; i < row.length; i++) if (row[i] == null) ps.setNull(i + 1, Types.VARCHAR); else ps.setString(i + 1, row[i]);
        ps.executeUpdate();
      }
    }
  }

  private int count(String table) throws SQLException {
    try (Statement s = connection.createStatement(); ResultSet rs = s.executeQuery("SELECT COUNT(*) FROM " + table)) { return rs.next() ? rs.getInt(1) : 0; }
  }

  private void handle(HttpExchange exchange) throws IOException {
    try {
      addCors(exchange);
      if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) { send(exchange, 204, ""); return; }
      String path = exchange.getRequestURI().getPath();
      if (path.startsWith("/api")) path = path.substring(4);
      String method = exchange.getRequestMethod().toUpperCase(Locale.ROOT);
      JsonObject body = readBody(exchange);
      if ("/healthz".equals(path)) { sendJson(exchange, 200, obj("status", "ok")); return; }
      if ("/auth/login".equals(path) && "POST".equals(method)) {
        String username = text(body, "username"), password = text(body, "password");
        if ("admin".equals(username) && "admin123".equals(password)) sendJson(exchange, 200, obj("success", true, "name", "Aarav Sharma"));
        else sendJson(exchange, 401, obj("error", "Invalid username or password"));
        return;
      }
      if ("/dashboard".equals(path)) { sendJson(exchange, 200, dashboard()); return; }
      if ("/employees".equals(path)) { collection(exchange, method, "employees", body); return; }
      if ("/customers".equals(path)) { collection(exchange, method, "customers", body); return; }
      if ("/assignments".equals(path)) { assignments(exchange, method, body); return; }
      if ("/visits".equals(path) && "GET".equals(method)) { sendJson(exchange, 200, visits()); return; }
      if ("/recordings".equals(path) && "GET".equals(method)) { sendJson(exchange, 200, queryRows("SELECT * FROM recordings ORDER BY id DESC", this::recording)); return; }
      if ("/announcements".equals(path)) { announcements(exchange, method, body); return; }
      if ("/activities".equals(path) && "GET".equals(method)) { sendJson(exchange, 200, queryRows("SELECT * FROM activities ORDER BY id DESC", this::activity)); return; }
      if ("/profile".equals(path)) { profile(exchange, method, body); return; }
      if (path.matches("/(employees|customers|assignments|recordings|announcements)/\\d+")) { item(exchange, method, path, body); return; }
      sendJson(exchange, 404, obj("error", "Not found"));
    } catch (Exception error) {
      error.printStackTrace();
      sendJson(exchange, 500, obj("error", error.getMessage() == null ? "Server error" : error.getMessage()));
    }
  }

  private void collection(HttpExchange e, String method, String table, JsonObject body) throws Exception {
    if ("GET".equals(method)) {
      String query = e.getRequestURI().getQuery();
      String search = queryValue(query, "search"), status = queryValue(query, "status");
      String sql = "SELECT * FROM " + table;
      if (search != null && !search.isBlank()) sql += " WHERE (name LIKE ? OR email LIKE ? OR phone LIKE ? OR " + (table.equals("employees") ? "employee_id" : "customer_id") + " LIKE ?)";
      if (status != null && !status.isBlank()) sql += (sql.contains("WHERE") ? " AND " : " WHERE ") + " status = ?";
      sql += " ORDER BY id DESC";
      sendJson(e, 200, queryRows(sql, statement -> {
        if (search != null && !search.isBlank()) { String term = "%" + search + "%"; for (int i=1;i<=4;i++) statement.setString(i, term); }
        if (status != null && !status.isBlank()) statement.setString((search != null && !search.isBlank()) ? 5 : 1, status);
      }, table.equals("employees") ? this::employee : this::customer));
    } else if ("POST".equals(method)) {
      if ("employees".equals(table)) {
        String validationError = validateEmployee(body);
        if (validationError != null) {
          sendJson(e, 400, obj("error", validationError));
          return;
        }
        int id = insertEmployee(body);
        sendJson(e, 201, one("SELECT * FROM employees WHERE id=" + id, this::employee));
      } else {
        String validationError = validateCustomer(body);
        if (validationError != null) {
          sendJson(e, 400, obj("error", validationError));
          return;
        }
        int id = insertCustomer(body);
        sendJson(e, 201, one("SELECT * FROM customers WHERE id=" + id, this::customer));
      }
    } else sendJson(e, 405, obj("error", "Method not allowed"));
  }

  private void item(HttpExchange e, String method, String path, JsonObject body) throws Exception {
    String[] parts = path.substring(1).split("/");
    String table = parts[0], id = parts[1];
    if ("DELETE".equals(method)) {
      String sql = "DELETE FROM " + table + " WHERE id=?";
      try (PreparedStatement ps = connection.prepareStatement(sql)) { ps.setInt(1, Integer.parseInt(id)); ps.executeUpdate(); }
      send(e, 204, "");
    } else if ("PATCH".equals(method)) {
      if ("employees".equals(table)) {
        String validationError = validateEmployee(body);
        if (validationError != null) {
          sendJson(e, 400, obj("error", validationError));
          return;
        }
        updateEmployee(body, id);
      }
      else if ("customers".equals(table)) {
        String validationError = validateCustomer(body);
        if (validationError != null) {
          sendJson(e, 400, obj("error", validationError));
          return;
        }
        updateCustomer(body, id);
      }
      else if ("assignments".equals(table)) update("UPDATE assignments SET customer_id=?,employee_id=?,position=?,assigned_date=? WHERE id=?", body, new String[]{"customerId","employeeId","position","assignedDate"}, id);
      else if ("announcements".equals(table)) update("UPDATE announcements SET title=?,message=?,published=?,date=? WHERE id=?", body, new String[]{"title","message","published","date"}, id);
      else { sendJson(e, 400, obj("error","Unsupported update")); return; }
      RowMapper mapper = table.equals("employees") ? this::employee
          : table.equals("customers") ? this::customer
          : table.equals("assignments") ? this::assignment
          : this::announcement;
      String select = "assignments".equals(table)
          ? "SELECT a.*, c.name customer_name, e.name employee_name FROM assignments a JOIN customers c ON c.id=a.customer_id JOIN employees e ON e.id=a.employee_id WHERE a.id="
          : "SELECT * FROM " + table + " WHERE id=";
      sendJson(e, 200, one(select + Integer.parseInt(id), mapper));
    } else sendJson(e, 405, obj("error", "Method not allowed"));
  }

  private void assignments(HttpExchange e, String method, JsonObject body) throws Exception {
    if ("GET".equals(method)) { sendJson(e, 200, queryRows("SELECT a.*, c.name customer_name, e.name employee_name FROM assignments a JOIN customers c ON c.id=a.customer_id JOIN employees e ON e.id=a.employee_id ORDER BY a.id DESC", this::assignment)); return; }
    if ("POST".equals(method)) { int id = insert("INSERT INTO assignments(customer_id,employee_id,position,assigned_date) VALUES(?,?,?,?)", body, "customerId","employeeId","position","assignedDate"); sendJson(e, 201, one("SELECT a.*, c.name customer_name, e.name employee_name FROM assignments a JOIN customers c ON c.id=a.customer_id JOIN employees e ON e.id=a.employee_id WHERE a.id=" + id, this::assignment)); return; }
    sendJson(e, 405, obj("error", "Method not allowed"));
  }

  private void announcements(HttpExchange e, String method, JsonObject body) throws Exception {
    if ("GET".equals(method)) { sendJson(e, 200, queryRows("SELECT * FROM announcements ORDER BY id DESC", this::announcement)); return; }
    if ("POST".equals(method)) { int id = insert("INSERT INTO announcements(title,message,published,date) VALUES(?,?,?,?)", body, "title","message","published","date"); sendJson(e, 201, one("SELECT * FROM announcements WHERE id=" + id, this::announcement)); return; }
    sendJson(e, 405, obj("error", "Method not allowed"));
  }

  private void profile(HttpExchange e, String method, JsonObject body) throws Exception {
    if ("GET".equals(method)) { sendJson(e, 200, one("SELECT * FROM profile WHERE id=1", this::profile)); return; }
    if ("PATCH".equals(method)) { update("UPDATE profile SET name=?,email=?,phone=?,picture=? WHERE id=1", body, new String[]{"name","email","phone","picture"}, null); sendJson(e, 200, one("SELECT * FROM profile WHERE id=1", this::profile)); return; }
    sendJson(e, 405, obj("error", "Method not allowed"));
  }

  private JsonObject dashboard() throws SQLException {
    JsonObject out = new JsonObject(), stats = new JsonObject();
    stats.addProperty("employees", count("employees")); stats.addProperty("customers", count("customers"));
    stats.addProperty("assigned", scalar("SELECT COUNT(*) FROM customers WHERE status='Assigned'"));
    stats.addProperty("interested", scalar("SELECT COUNT(*) FROM customers WHERE status='Interested'"));
    stats.addProperty("notInterested", scalar("SELECT COUNT(*) FROM customers WHERE status='Not Interested'"));
    stats.addProperty("scheduledVisits", scalar("SELECT COUNT(*) FROM visits WHERE status='Scheduled'"));
    stats.addProperty("completedVisits", scalar("SELECT COUNT(*) FROM visits WHERE status='Completed'"));
    out.add("stats", stats);
    JsonArray breakdown = new JsonArray();
    try (PreparedStatement ps=connection.prepareStatement("SELECT status,COUNT(*) count FROM customers GROUP BY status ORDER BY count DESC"); ResultSet rs=ps.executeQuery()) { while(rs.next()){ JsonObject row=new JsonObject(); row.addProperty("status",rs.getString(1)); row.addProperty("count",rs.getInt(2)); breakdown.add(row); } }
    out.add("statusBreakdown", breakdown); out.add("recentEmployees", queryRows("SELECT * FROM employees ORDER BY id DESC LIMIT 4", this::employee)); out.add("recentCustomers", queryRows("SELECT * FROM customers ORDER BY id DESC LIMIT 5", this::customer)); out.add("recentVisits", visits());
    return out;
  }

  private JsonArray visits() throws SQLException { return queryRows("SELECT * FROM visits ORDER BY id DESC", this::visit); }
  private int scalar(String sql) throws SQLException { try (Statement s=connection.createStatement(); ResultSet r=s.executeQuery(sql)){return r.next()?r.getInt(1):0;} }
  private int insertCustomer(JsonObject body) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(
        "INSERT INTO customers(customer_id,name,phone,email,address,property,status,updated_at) VALUES(?,?,?,?,?,?,?,?)",
        Statement.RETURN_GENERATED_KEYS)) {
      String[] keys = {"customerId", "name", "phone", "email", "address", "property", "status"};
      for (int i = 0; i < keys.length; i++) set(ps, i + 1, body, keys[i]);
      ps.setString(8, LocalDate.now().format(DISPLAY_DATE));
      ps.executeUpdate();
      try (ResultSet keysResult = ps.getGeneratedKeys()) {
        return keysResult.next() ? keysResult.getInt(1) : 0;
      }
    }
  }
  private void updateCustomer(JsonObject body, String id) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(
        "UPDATE customers SET customer_id=?,name=?,phone=?,email=?,address=?,property=?,status=?,updated_at=? WHERE id=?")) {
      String[] keys = {"customerId", "name", "phone", "email", "address", "property", "status"};
      for (int i = 0; i < keys.length; i++) set(ps, i + 1, body, keys[i]);
      ps.setString(8, LocalDate.now().format(DISPLAY_DATE));
      ps.setInt(9, Integer.parseInt(id));
      ps.executeUpdate();
    }
  }
  private int insertEmployee(JsonObject body) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(
        "INSERT INTO employees(employee_id,name,email,phone,position,status,joined_date) VALUES(?,?,?,?,?,?,?)",
        Statement.RETURN_GENERATED_KEYS)) {
      String[] keys = {"employeeId", "name", "email", "phone", "position"};
      for (int i = 0; i < keys.length; i++) set(ps, i + 1, body, keys[i]);
      ps.setString(6, text(body, "status").trim().isEmpty() ? "Active" : text(body, "status").trim());
      ps.setString(7, LocalDate.now().toString());
      ps.executeUpdate();
      try (ResultSet keysResult = ps.getGeneratedKeys()) {
        return keysResult.next() ? keysResult.getInt(1) : 0;
      }
    }
  }
  private void updateEmployee(JsonObject body, String id) throws SQLException {
    try (PreparedStatement ps = connection.prepareStatement(
        "UPDATE employees SET employee_id=?,name=?,email=?,phone=?,position=?,status=? WHERE id=?")) {
      String[] keys = {"employeeId", "name", "email", "phone", "position"};
      for (int i = 0; i < keys.length; i++) set(ps, i + 1, body, keys[i]);
      ps.setString(6, text(body, "status").trim().isEmpty() ? "Active" : text(body, "status").trim());
      ps.setInt(7, Integer.parseInt(id));
      ps.executeUpdate();
    }
  }
  private String validateEmployee(JsonObject body) {
    String[][] required = {
        {"employeeId", "Employee ID"},
        {"name", "Employee name"},
        {"email", "Email"},
        {"phone", "Phone number"},
        {"position", "Position"}
    };
    for (String[] field : required) {
      if (text(body, field[0]).trim().isEmpty()) return field[1] + " is required.";
    }
    String email = text(body, "email").trim();
    if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) return "Enter a valid email address.";
    if (text(body, "phone").trim().replaceAll("[^0-9+]", "").length() < 7) return "Enter a valid phone number.";
    return null;
  }
  private String validateCustomer(JsonObject body) {
    String[][] required = {
        {"customerId", "Customer ID"},
        {"name", "Customer name"},
        {"phone", "Phone number"},
        {"email", "Email"},
        {"address", "Address"},
        {"property", "Interested property"},
        {"status", "Customer status"}
    };
    for (String[] field : required) {
      if (text(body, field[0]).trim().isEmpty()) return field[1] + " is required.";
    }
    String email = text(body, "email").trim();
    if (!email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) return "Enter a valid email address.";
    if (text(body, "phone").trim().replaceAll("[^0-9+]", "").length() < 7) return "Enter a valid phone number.";
    return null;
  }
  private int insert(String sql, JsonObject body, String... keys) throws SQLException {
    try (PreparedStatement ps=connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) { for(int i=0;i<keys.length;i++) set(ps,i+1,body,keys[i]); ps.executeUpdate(); try(ResultSet r=ps.getGeneratedKeys()){return r.next()?r.getInt(1):0;} }
  }
  private void update(String sql, JsonObject body, String[] keys, String id) throws SQLException {
    try (PreparedStatement ps=connection.prepareStatement(sql)) { for(int i=0;i<keys.length;i++) set(ps,i+1,body,keys[i]); if(id!=null) ps.setInt(keys.length+1,Integer.parseInt(id)); ps.executeUpdate(); }
  }
  private void set(PreparedStatement ps,int index,JsonObject body,String key) throws SQLException { JsonElement v=body.get(key); if(v==null||v.isJsonNull()) ps.setNull(index,Types.VARCHAR); else if(v.isJsonPrimitive()&&v.getAsJsonPrimitive().isBoolean()) ps.setInt(index,v.getAsBoolean()?1:0); else if(v.isJsonPrimitive()&&v.getAsJsonPrimitive().isNumber()) ps.setInt(index,v.getAsInt()); else ps.setString(index,v.getAsString()); }

  private interface Binder { void bind(PreparedStatement s) throws SQLException; }
  private interface RowMapper { JsonObject map(ResultSet r) throws SQLException; }
  private JsonArray queryRows(String sql, RowMapper mapper) throws SQLException { return queryRows(sql, statement -> {}, mapper); }
  private JsonArray queryRows(String sql, Binder binder, RowMapper mapper) throws SQLException { JsonArray a=new JsonArray(); try(PreparedStatement ps=connection.prepareStatement(sql)){binder.bind(ps);try(ResultSet r=ps.executeQuery()){while(r.next())a.add(mapper.map(r));}}return a; }
  private JsonObject one(String sql, RowMapper mapper) throws SQLException { JsonArray a=queryRows(sql,mapper); return a.size()>0?a.get(0).getAsJsonObject():new JsonObject(); }
  private JsonObject employee(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("employeeId",r.getString("employee_id"));o.addProperty("name",r.getString("name"));o.addProperty("email",r.getString("email"));o.addProperty("phone",r.getString("phone"));o.addProperty("position",r.getString("position"));o.addProperty("status",r.getString("status"));o.addProperty("joinedDate",r.getString("joined_date"));return o;}
  private JsonObject customer(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("customerId",r.getString("customer_id"));o.addProperty("name",r.getString("name"));o.addProperty("phone",r.getString("phone"));o.addProperty("email",r.getString("email"));o.addProperty("address",r.getString("address"));o.addProperty("property",r.getString("property"));o.addProperty("status",r.getString("status"));o.addProperty("updatedAt",r.getString("updated_at"));return o;}
  private JsonObject assignment(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("customerId",r.getInt("customer_id"));o.addProperty("customerName",r.getString("customer_name"));o.addProperty("employeeId",r.getInt("employee_id"));o.addProperty("employeeName",r.getString("employee_name"));o.addProperty("position",r.getString("position"));o.addProperty("assignedDate",r.getString("assigned_date"));return o;}
  private JsonObject visit(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("customerName",r.getString("customer_name"));o.addProperty("employeeName",r.getString("employee_name"));o.addProperty("scheduledAt",r.getString("scheduled_at"));o.addProperty("status",r.getString("status"));o.addProperty("completedAt",r.getString("completed_at"));o.addProperty("selfie",r.getString("selfie"));return o;}
  private JsonObject recording(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("customerName",r.getString("customer_name"));o.addProperty("employeeName",r.getString("employee_name"));o.addProperty("recordedAt",r.getString("recorded_at"));o.addProperty("duration",r.getString("duration"));o.addProperty("status",r.getString("status"));return o;}
  private JsonObject announcement(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("title",r.getString("title"));o.addProperty("message",r.getString("message"));o.addProperty("published",r.getInt("published")==1);o.addProperty("date",r.getString("date"));return o;}
  private JsonObject activity(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("employeeName",r.getString("employee_name"));o.addProperty("loginTime",r.getString("login_time"));o.addProperty("logoutTime",r.getString("logout_time"));o.addProperty("activity",r.getString("activity"));o.addProperty("date",r.getString("date"));return o;}
  private JsonObject profile(ResultSet r)throws SQLException{JsonObject o=base(r);o.addProperty("name",r.getString("name"));o.addProperty("email",r.getString("email"));o.addProperty("phone",r.getString("phone"));o.addProperty("picture",r.getString("picture"));o.addProperty("initials",r.getString("picture"));return o;}
  private JsonObject base(ResultSet r)throws SQLException{JsonObject o=new JsonObject();o.addProperty("id",r.getInt("id"));return o;}
  private JsonObject readBody(HttpExchange e)throws IOException{String raw=new String(e.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);return raw.isBlank()?new JsonObject():JsonParser.parseString(raw).getAsJsonObject();}
  private static String text(JsonObject o,String k){return o.has(k)?o.get(k).getAsString():"";}
  private static String queryValue(String query,String key){if(query==null)return null;for(String part:query.split("&")){String[] p=part.split("=",2);if(p.length==2&&p[0].equals(key))return p[1].replace("+"," ");}return null;}
  private static JsonObject obj(Object... values){JsonObject o=new JsonObject();for(int i=0;i<values.length;i+=2){Object v=values[i+1];if(v instanceof Boolean)o.addProperty(values[i].toString(),(Boolean)v);else o.addProperty(values[i].toString(),String.valueOf(v));}return o;}
  private static void addCors(HttpExchange e){e.getResponseHeaders().set("Access-Control-Allow-Origin","*");e.getResponseHeaders().set("Access-Control-Allow-Headers","Content-Type");e.getResponseHeaders().set("Access-Control-Allow-Methods","GET,POST,PATCH,DELETE,OPTIONS");}
  private static void sendJson(HttpExchange e,int code,Object payload)throws IOException{send(e,code,GSON.toJson(payload));}
  private static void send(HttpExchange e,int code,String body)throws IOException{byte[] b=body.getBytes(StandardCharsets.UTF_8);e.getResponseHeaders().set("Content-Type","application/json; charset=utf-8");e.sendResponseHeaders(code,code==204? -1:b.length);if(code!=204)try(OutputStream out=e.getResponseBody()){out.write(b);}}
}