# Real Estate Management System – Admin Dashboard

Java-backed admin console for managing real estate employees, customers, assignments, visits, recordings, announcements, activities, and the administrator profile.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Java API server on the managed `/api` service
- `pnpm --filter @workspace/real-estate-admin run dev` — run the React/Vite admin UI
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `mvn -q -f artifacts/real-estate-admin/server/pom.xml compile` — compile the Java API
- SQLite data is stored by the Java API under `artifacts/real-estate-admin/server/data/` when started directly, or the API service working directory when started through its managed workflow.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Java `HttpServer` with SQLite JDBC
- DB: SQLite
- Frontend: React + Vite + TanStack Query
- API codegen: Orval (from OpenAPI spec)
- Build: Vite

## Where things live

- `artifacts/real-estate-admin/server/src/main/java/com/realestate/AdminServer.java` — Java HTTP API, SQLite schema, seed data, and route handlers
- `artifacts/real-estate-admin/src/App.tsx` — admin login, shell, routes, CRUD screens, forms, and dashboard
- `artifacts/real-estate-admin/src/index.css` — shared “ink + parchment + vermilion” visual system
- `lib/api-spec/openapi.yaml` — source-of-truth API contract

## Architecture decisions

- The existing `/api` artifact workflow runs the Java service so path-based routing reaches the required Java backend instead of the starter TypeScript server.
- The web artifact remains a React/Vite frontend, with generated API hooks calling the Java service through the shared `/api` route.
- Demo data is seeded only when each SQLite table is empty, so later restarts preserve user-created records.

## Product

Admin-only real estate operations console with demo login (`admin` / `admin123`), dashboard KPIs, employee and customer CRUD, assignment management, visit updates, recording history, announcements, activity history, and profile editing.

## User preferences

- User explicitly requested Java instead of Python; keep the backend Java-based.

## Gotchas

- The managed API workflow owns `/api`; restart both managed app workflows after changes to Java or frontend code.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
